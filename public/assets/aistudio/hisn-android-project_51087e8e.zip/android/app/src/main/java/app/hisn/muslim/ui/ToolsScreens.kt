@file:OptIn(ExperimentalMaterial3Api::class)

package app.hisn.muslim.ui

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.hisn.muslim.data.AppViewModel
import app.hisn.muslim.data.arabicDigits

private val PHRASES = listOf(
    "سُبْحَانَ اللَّهِ",
    "الْحَمْدُ لِلَّهِ",
    "اللَّهُ أَكْبَرُ",
    "لَا إِلَهَ إِلَّا اللَّهُ",
    "أَسْتَغْفِرُ اللَّهَ",
    "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
)

@Composable
fun TasbihScreen(vm: AppViewModel) {
    val view = LocalView.current
    val count = vm.tasbihCounts[vm.tasbihPhrase] ?: 0
    val target = vm.tasbihTarget
    val inRound = count % target
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            "المسبحة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth(),
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(PHRASES) { i, p ->
                FilterChip(
                    selected = i == vm.tasbihPhrase, onClick = { vm.setTasbihPhrase(i) },
                    label = { Text(p, fontFamily = ReadFont) },
                )
            }
        }
        Text(PHRASES[vm.tasbihPhrase], style = readStyle(1f, 28f), textAlign = TextAlign.Center)
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(260.dp)) {
            CircularProgressIndicator(
                progress = { if (inRound == 0 && count > 0) 1f else inRound / target.toFloat() },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 10.dp,
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Box(
                Modifier.size(224.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable {
                        vm.tasbihTap()
                        if (vm.haptics) {
                            val c = (vm.tasbihCounts[vm.tasbihPhrase] ?: 0)
                            view.performHapticFeedback(
                                if (c % target == 0) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.VIRTUAL_KEY,
                            )
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(arabicDigits(count), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("من ${arabicDigits(target)}", color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        Text("الدورات المكتملة: ${arabicDigits(count / target)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100, 1000).forEach { t ->
                FilterChip(selected = target == t, onClick = { vm.setTasbihTarget(t) }, label = { Text(arabicDigits(t)) })
            }
        }
        OutlinedButton({ vm.tasbihReset() }) {
            Icon(Icons.Filled.Refresh, null)
            Text("  تصفير العدّاد")
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, onAbout: () -> Unit) {
    val ctx = LocalContext.current
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Section("المظهر") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("تلقائي", "فاتح", "داكن").forEachIndexed { i, n ->
                    FilterChip(selected = vm.themeMode == i, onClick = { vm.setTheme(i) }, label = { Text(n) })
                }
            }
            Text("حجم الخط", style = MaterialTheme.typography.labelLarge)
            Slider(value = vm.fontScale, onValueChange = { vm.setFontScale(it) }, valueRange = 0.8f..1.7f)
            Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", style = readStyle(vm.fontScale))
        }

        Section("القراءة") {
            SwitchRow("إبقاء الشاشة مضاءة أثناء القراءة", vm.keepOn) { vm.setKeepOn(it) }
            SwitchRow("اهتزاز خفيف عند العدّ", vm.haptics) { vm.setHaptics(it) }
        }

        Section("التذكيرات") {
            listOf("أذكار الصباح", "أذكار المساء").forEachIndexed { kind, name ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name)
                        TextButton({
                            TimePickerDialog(ctx, { _, h, m -> vm.setReminder(kind, vm.remOn[kind], h, m) }, vm.remH[kind], vm.remM[kind], false).show()
                        }) {
                            val h = vm.remH[kind]
                            val h12 = if (h % 12 == 0) 12 else h % 12
                            Text("${arabicDigits(h12)}:${arabicDigits(vm.remM[kind]).padStart(2, '٠')} ${if (h < 12) "ص" else "م"}")
                        }
                    }
                    Switch(checked = vm.remOn[kind], onCheckedChange = { on ->
                        if (on && Build.VERSION.SDK_INT >= 33) askPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                        vm.setReminder(kind, on)
                    })
                }
            }
        }

        Section("عن التطبيق") {
            FilledTonalButton(onAbout, Modifier.fillMaxWidth()) { Text("المصادر والمعلومات") }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    androidx.compose.material3.Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        topBar = { BackTopBar("المصادر والمعلومات", onBack) },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp + navBarBottom(0.dp).calculateBottomPadding()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val lines = listOf(
                "الكتاب" to "حصن المسلم، لمؤلفه الشيخ د. سعيد بن علي بن وهف القحطاني رحمه الله.",
                "الشرح" to "من كتاب «إتحاف المسلم بشرح حصن المسلم» للمؤلف نفسه.",
                "المصدر الرسمي" to "www.binwahaf.com",
                "المادة العلمية" to "مأخوذة من تطبيق «حصن المسلم» الصادر عن الدار العربية لتقنية المعلومات.",
                "الخصوصية" to "التطبيق يعمل دون إنترنت، ولا يجمع أي بيانات، ولا يحتوي على إعلانات.",
                "الخطوط" to "خط «ثمانية» (Thmanyah) لشركة ثمانية، ويُستخدم وفق ترخيصها: font.thmanyah.com/licenses. وخط «الأميري القرآني» لكتابة الآيات برخصة SIL OFL.",
                "الإصدار" to "١٫٠٫٠ — نسخة مُهداة غير تجارية.",
            )
            lines.forEach { (k, v) ->
                Column {
                    Text(k, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(v)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
            Text("لا تنسونا من صالح دعائكم.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
