package app.hisn.muslim.data

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle

// Markup used in azkar.json: <v>verse</v>  <s>narrator note</s>  <n>k</n> footnote marker
private val TAG = Regex("<v>|</v>|<s>|</s>|<n>(\\d+)</n>")
private val MARKER = Regex("\\s*<n>\\d+</n>")

fun arabicDigits(n: Int): String = n.toString().map { '٠' + (it - '0') }.joinToString("")

fun rich(src: String, verse: SpanStyle, note: SpanStyle, mark: SpanStyle): AnnotatedString = buildAnnotatedString {
    var last = 0
    var inV = false
    var inS = false
    fun emit(t: String) {
        if (t.isEmpty()) return
        when {
            inV -> withStyle(verse) { append(t) }
            inS -> withStyle(note) { append(t) }
            else -> append(t)
        }
    }
    for (m in TAG.findAll(src)) {
        emit(src.substring(last, m.range.first))
        last = m.range.last + 1
        when (m.value) {
            "<v>" -> { inV = true; withStyle(verse) { append("﴿") } }
            "</v>" -> { withStyle(verse) { append("﴾") }; inV = false }
            "<s>" -> { inS = true; withStyle(note) { append("[") } }
            "</s>" -> { withStyle(note) { append("]") }; inS = false }
            else -> withStyle(mark) { append(arabicDigits(m.groupValues[1].toInt())) }
        }
    }
    emit(src.substring(last))
}

/** Clean text for copying / sharing / searching. */
fun plain(src: String): String = src
    .replace(MARKER, "")
    .replace("<v>", "﴿").replace("</v>", "﴾")
    .replace("<s>", "[").replace("</s>", "]")

fun Zekr.copyZekr(withSource: Boolean = true): String =
    plain(text) + if (withSource && footnote.isNotBlank()) "\n\n$footnote" else ""

fun Zekr.copyAll(): String = buildString {
    append(catTitle).append("\n\n").append(copyZekr(true))
    if (repeat > 1) append("\n\nيُقال ").append(arabicDigits(repeat)).append(" مرات")
    if (sharh.isNotBlank()) append("\n\n— الشرح —\n").append(plain(sharh))
    if (hadeth.isNotBlank()) append("\n\n— الحديث —\n").append(plain(hadeth))
    if (benefit.isNotBlank()) append("\n\n— الفوائد —\n").append(plain(benefit))
}

fun Zekr.shareText(): String = copyZekr(true) + "\n\n— حصن المسلم"
