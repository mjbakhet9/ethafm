package app.hisn.muslim.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import app.hisn.muslim.R

/** Thmanyah (ثمانية): Sans for the interface, Serif Text for reading, Serif Display for big titles. */
val SansFont = FontFamily(Font(R.font.thmanyah_sans_regular), Font(R.font.thmanyah_sans_bold, FontWeight.Bold))
val ReadFont = FontFamily(Font(R.font.thmanyah_serif_text_regular), Font(R.font.thmanyah_serif_text_bold, FontWeight.Bold))
val DisplayFont = FontFamily(Font(R.font.thmanyah_display_bold, FontWeight.Bold))

/** Amiri Quran only for Quranic verses: Thmanyah has no Quranic annotation marks. */
val QuranFont = FontFamily(Font(R.font.amiri_quran))

private val Light = lightColorScheme(
    primary = Color(0xFF0F5C4D), onPrimary = Color.White,
    primaryContainer = Color(0xFFCFEADF), onPrimaryContainer = Color(0xFF00201A),
    secondaryContainer = Color(0xFFE6EFE9), onSecondaryContainer = Color(0xFF14332B),
    tertiary = Color(0xFF9A7515),
    background = Color(0xFFFBF8F1), onBackground = Color(0xFF1C1B17),
    surface = Color(0xFFFBF8F1), onSurface = Color(0xFF1C1B17),
    surfaceVariant = Color(0xFFEDE8DA), onSurfaceVariant = Color(0xFF4A4639),
    surfaceContainer = Color(0xFFF3EFE3), surfaceContainerHigh = Color(0xFFEDE8DA),
    outlineVariant = Color(0xFFD0CABA),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD3B8), onPrimary = Color(0xFF00382E),
    primaryContainer = Color(0xFF14463B), onPrimaryContainer = Color(0xFFB5F0DD),
    secondaryContainer = Color(0xFF1E3A32), onSecondaryContainer = Color(0xFFCDE9DF),
    tertiary = Color(0xFFE7C46A),
    background = Color(0xFF101514), onBackground = Color(0xFFE6E2D9),
    surface = Color(0xFF101514), onSurface = Color(0xFFE6E2D9),
    surfaceVariant = Color(0xFF243230), onSurfaceVariant = Color(0xFFC2C9C4),
    surfaceContainer = Color(0xFF182120), surfaceContainerHigh = Color(0xFF1F2A28),
    outlineVariant = Color(0xFF3B4A46),
)

private fun Typography.withFont(f: FontFamily): Typography {
    fun TextStyle.w() = copy(fontFamily = f)
    return copy(
        displayLarge = displayLarge.w(), displayMedium = displayMedium.w(), displaySmall = displaySmall.w(),
        headlineLarge = headlineLarge.w(), headlineMedium = headlineMedium.w(), headlineSmall = headlineSmall.w(),
        titleLarge = titleLarge.w(), titleMedium = titleMedium.w(), titleSmall = titleSmall.w(),
        bodyLarge = bodyLarge.w(), bodyMedium = bodyMedium.w(), bodySmall = bodySmall.w(),
        labelLarge = labelLarge.w(), labelMedium = labelMedium.w(), labelSmall = labelSmall.w(),
    )
}

private val AppTypography = Typography().withFont(SansFont)

@Composable
fun HisnTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = AppTypography, content = content)
}
