@file:OptIn(ExperimentalMaterial3Api::class)

package app.hisn.muslim.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.hisn.muslim.data.AppViewModel
import app.hisn.muslim.data.Category
import app.hisn.muslim.data.Hit
import app.hisn.muslim.data.Store
import app.hisn.muslim.data.Zekr
import app.hisn.muslim.data.arabicDigits
import app.hisn.muslim.data.plain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate

private class Quick(val catId: Int, val title: String, val icon: ImageVector)

private val QUICK = listOf(
    Quick(27, "أذكار الصباح", Icons.Filled.WbSunny),
    Quick(135, "أذكار المساء", Icons.Filled.NightsStay),
    Quick(28, "أذكار النوم", Icons.Filled.Bedtime),
    Quick(25, "بعد الصلاة", Icons.Filled.Mosque),
)

@Composable
fun HomeScreen(vm: AppViewModel, onCat: (Int) -> Unit, onSearch: () -> Unit, onZekr: (Int, Int) -> Unit) {
    val cats = Store.cats
    val daily = remember {
        val short = Store.all().filter { it.text.length < 260 }
        short[(LocalDate.now().toEpochDay() % short.size).toInt()]
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = SpaceV,
    ) {
        item {
            Text("حصن المسلم", style = MaterialTheme.typography.headlineMedium, fontFamily = DisplayFont, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("من أذكار الكتاب والسنة مع الشرح", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Card(
                onClick = onSearch,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                shape = RoundedCornerShape(28.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(12.dp))
                    Text("ابحث في الأذكار والشروحات", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                QUICK.chunked(2).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowItems.forEach { q ->
                            val cat = Store.cat(q.catId)
                            QuickCard(q, cat?.let { vm.doneIn(it) } ?: 0, cat?.azkar?.size ?: 0, Modifier.weight(1f)) { onCat(q.catId) }
                        }
                    }
                }
            }
        }
        val last = Store.cat(vm.lastCat)
        if (last != null) {
            item {
                Card(
                    onClick = { onZekr(last.id, vm.lastIdx.coerceIn(0, last.azkar.size - 1)) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("تابع من حيث توقفت", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(last.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
        }
        item { DailyCard(daily) { onZekr(daily.catId, daily.idx) } }
        item { Text("جميع الأقسام", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(cats, key = { it.id }) { c -> CategoryRow(c, vm) { onCat(c.id) } }
    }
}

@Composable
private fun QuickCard(q: Quick, done: Int, total: Int, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(q.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Text(q.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Text(
                if (done > 0) "أُنجز ${arabicDigits(done)} من ${arabicDigits(total)}" else "${arabicDigits(total)} ذكرًا",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
        }
    }
}

@Composable
private fun DailyCard(z: Zekr, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ذكر اليوم", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
            Text(
                rememberRich(z.text),
                style = readStyle(0.85f),
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
            )
            Text(z.catTitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryRow(c: Category, vm: AppViewModel, onClick: () -> Unit) {
    val done = vm.doneIn(c)
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(c.title, style = MaterialTheme.typography.bodyLarge)
        }
        if (done > 0 && done == c.azkar.size) {
            Text("✓ ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Text(arabicDigits(c.azkar.size), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SearchScreen(onBack: () -> Unit, onZekr: (Int, Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(query) {
        delay(250)
        hits = withContext(Dispatchers.Default) { Store.search(query) }
    }
    Column(Modifier.fillMaxSize()) {
        BackTopBar("بحث", onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).focusRequester(focus),
            placeholder = { Text("اكتب كلمة من الذكر أو الشرح…") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Clear, "مسح") }
            },
        )
        if (query.trim().length >= 2 && hits.isEmpty()) {
            Text("لا توجد نتائج", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 16.dp + navBarBottom(0.dp).calculateBottomPadding()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(hits, key = { it.zekr.id }) { h ->
                Card(
                    onClick = { onZekr(h.zekr.catId, h.zekr.idx) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row {
                            Text(h.zekr.catTitle, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("في ${h.where}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                        }
                        Text(plain(h.snippet), style = readStyle(0.8f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(vm: AppViewModel, onZekr: (Int, Int) -> Unit) {
    val items = vm.favorites.mapNotNull { Store.zekr(it) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "المفضلة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.primary,
        )
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text("لم تضف شيئًا إلى المفضلة بعد.\nاضغط على القلب في أي ذكر لحفظه هنا.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items, key = { it.id }) { z ->
                    Card(
                        onClick = { onZekr(z.catId, z.idx) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    ) {
                        Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(z.catTitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
                                Text(rememberRich(z.text), style = readStyle(0.8f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton({ vm.toggleFav(z.id) }) {
                                Icon(Icons.Filled.Favorite, "إزالة", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}
