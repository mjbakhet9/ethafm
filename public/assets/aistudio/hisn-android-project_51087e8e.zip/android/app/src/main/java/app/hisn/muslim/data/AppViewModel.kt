package app.hisn.muslim.data

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.hisn.muslim.reminders.Reminders
import kotlinx.coroutines.launch
import java.time.LocalDate

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences(Reminders.PREFS, Context.MODE_PRIVATE)

    var ready by mutableStateOf(false)
        private set

    // ---- settings
    var themeMode by mutableIntStateOf(sp.getInt("theme", 0)) // 0 system, 1 light, 2 dark
        private set
    var fontScale by mutableFloatStateOf(sp.getFloat("font", 1f))
        private set
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
        private set
    var keepOn by mutableStateOf(sp.getBoolean("keepOn", true))
        private set

    fun setTheme(v: Int) { themeMode = v; sp.edit().putInt("theme", v).apply() }
    fun setFontScale(v: Float) { fontScale = v; sp.edit().putFloat("font", v).apply() }
    fun setHaptics(v: Boolean) { haptics = v; sp.edit().putBoolean("haptics", v).apply() }
    fun setKeepOn(v: Boolean) { keepOn = v; sp.edit().putBoolean("keepOn", v).apply() }

    // ---- favourites
    val favorites = mutableStateListOf<Int>().apply {
        addAll(sp.getString("fav", "")!!.split(',').mapNotNull { it.toIntOrNull() })
    }

    fun toggleFav(id: Int) {
        if (!favorites.remove(id)) favorites.add(0, id)
        sp.edit().putString("fav", favorites.joinToString(",")).apply()
    }

    // ---- today's counters (reset automatically every day)
    val counts = mutableStateMapOf<Int, Int>()

    private fun today() = LocalDate.now().toString()

    private fun saveCounts() {
        sp.edit().putString("cnt", counts.entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("cnt_day", today()).apply()
    }

    fun tap(z: Zekr): Boolean {
        val n = (counts[z.id] ?: 0) + 1
        counts[z.id] = n
        saveCounts()
        return n >= z.repeat
    }

    fun resetCategory(cat: Category) {
        cat.azkar.forEach { counts.remove(it.id) }
        saveCounts()
    }

    fun doneIn(cat: Category): Int = cat.azkar.count { (counts[it.id] ?: 0) >= it.repeat }

    // ---- last read
    var lastCat by mutableIntStateOf(sp.getInt("lastCat", 0))
        private set
    var lastIdx by mutableIntStateOf(sp.getInt("lastIdx", 0))
        private set

    fun setLastRead(cat: Int, idx: Int) {
        lastCat = cat; lastIdx = idx
        sp.edit().putInt("lastCat", cat).putInt("lastIdx", idx).apply()
    }

    // ---- tasbih
    var tasbihPhrase by mutableIntStateOf(sp.getInt("tp", 0))
        private set
    var tasbihTarget by mutableIntStateOf(sp.getInt("tt", 33))
        private set
    val tasbihCounts = mutableStateMapOf<Int, Int>().apply {
        sp.getString("tc", "")!!.split(',').forEach {
            val p = it.split(':')
            if (p.size == 2) p[0].toIntOrNull()?.let { k -> put(k, p[1].toIntOrNull() ?: 0) }
        }
    }

    fun setTasbihPhrase(i: Int) { tasbihPhrase = i; sp.edit().putInt("tp", i).apply() }
    fun setTasbihTarget(t: Int) { tasbihTarget = t; sp.edit().putInt("tt", t).apply() }

    fun tasbihTap() {
        tasbihCounts[tasbihPhrase] = (tasbihCounts[tasbihPhrase] ?: 0) + 1
        saveTasbih()
    }

    fun tasbihReset() {
        tasbihCounts[tasbihPhrase] = 0
        saveTasbih()
    }

    private fun saveTasbih() {
        sp.edit().putString("tc", tasbihCounts.entries.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    // ---- reminders: index 0 morning, 1 evening
    val remOn = mutableStateListOf(sp.getBoolean("r0_on", false), sp.getBoolean("r1_on", false))
    val remH = mutableStateListOf(sp.getInt("r0_h", 6), sp.getInt("r1_h", 17))
    val remM = mutableStateListOf(sp.getInt("r0_m", 0), sp.getInt("r1_m", 0))

    fun setReminder(kind: Int, on: Boolean, h: Int = remH[kind], m: Int = remM[kind]) {
        remOn[kind] = on; remH[kind] = h; remM[kind] = m
        sp.edit().putBoolean("r${kind}_on", on).putInt("r${kind}_h", h).putInt("r${kind}_m", m).apply()
        if (on) Reminders.schedule(app, kind) else Reminders.cancel(app, kind)
    }

    init {
        if (sp.getString("cnt_day", "") == today()) {
            sp.getString("cnt", "")!!.split(',').forEach {
                val p = it.split(':')
                if (p.size == 2) p[0].toIntOrNull()?.let { k -> counts[k] = p[1].toIntOrNull() ?: 0 }
            }
        }
        viewModelScope.launch {
            Store.load(app)
            ready = true
        }
    }
}
