package app.hisn.muslim.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class Zekr(
    val id: Int,
    val text: String,
    val repeat: Int,
    val footnote: String,
    val sharh: String,
    val hadeth: String,
    val benefit: String,
    val catId: Int,
    val catTitle: String,
    val idx: Int,
) {
    val hasExtras get() = sharh.isNotBlank() || hadeth.isNotBlank() || benefit.isNotBlank()
}

class Category(val id: Int, val title: String, val azkar: List<Zekr>)

class Hit(val zekr: Zekr, val where: String, val snippet: String)

object Store {
    @Volatile
    var cats: List<Category> = emptyList()
        private set
    private var byId: Map<Int, Category> = emptyMap()
    private var zById: Map<Int, Zekr> = emptyMap()
    private var all: List<Zekr> = emptyList()

    fun cat(id: Int): Category? = byId[id]
    fun zekr(id: Int): Zekr? = zById[id]
    fun all(): List<Zekr> = all

    suspend fun load(ctx: Context) = withContext(Dispatchers.IO) {
        if (cats.isNotEmpty()) return@withContext
        val json = ctx.assets.open("azkar.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONObject(json).getJSONArray("cats")
        val out = ArrayList<Category>(arr.length())
        val flat = ArrayList<Zekr>(400)
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val cid = c.getInt("id")
            val title = c.getString("title")
            val za = c.getJSONArray("z")
            val list = ArrayList<Zekr>(za.length())
            for (j in 0 until za.length()) {
                val z = za.getJSONObject(j)
                list.add(
                    Zekr(
                        z.getInt("id"), z.getString("t"), z.getInt("r"), z.getString("f"),
                        z.getString("sh"), z.getString("hd"), z.getString("bn"), cid, title, j,
                    ),
                )
            }
            out.add(Category(cid, title, list))
            flat.addAll(list)
        }
        byId = out.associateBy { it.id }
        zById = flat.associateBy { it.id }
        all = flat
        cats = out
    }

    private class Idx(val title: String, val text: String, val sharh: String, val hadeth: String, val benefit: String)

    private var index: List<Idx>? = null

    private fun ensureIndex(): List<Idx> = synchronized(this) {
        index ?: all.map {
            Idx(
                Arabic.normalize(it.catTitle), Arabic.normalize(plain(it.text)),
                Arabic.normalize(plain(it.sharh)), Arabic.normalize(plain(it.hadeth)), Arabic.normalize(plain(it.benefit)),
            )
        }.also { index = it }
    }

    fun search(query: String): List<Hit> {
        val tokens = Arabic.normalize(query.trim()).split(' ').filter { it.isNotEmpty() }
        if (tokens.isEmpty() || tokens.sumOf { it.length } < 2) return emptyList()
        val idx = ensureIndex()
        val hits = ArrayList<Hit>()
        for ((i, z) in all.withIndex()) {
            val x = idx[i]
            fun has(s: String) = tokens.all { s.contains(it) }
            val (where, src) = when {
                has(x.title) -> "القسم" to z.catTitle
                has(x.text) -> "الذكر" to plain(z.text)
                has(x.sharh) -> "الشرح" to plain(z.sharh)
                has(x.hadeth) -> "الحديث" to plain(z.hadeth)
                has(x.benefit) -> "الفوائد" to plain(z.benefit)
                else -> continue
            }
            hits.add(Hit(z, where, Arabic.snippet(src, tokens[0])))
            if (hits.size >= 80) break
        }
        return hits
    }
}
