package app.hisn.muslim

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.hisn.muslim.data.AppViewModel
import app.hisn.muslim.ui.AboutScreen
import app.hisn.muslim.ui.CategoryScreen
import app.hisn.muslim.ui.DetailScreen
import app.hisn.muslim.ui.FavoritesScreen
import app.hisn.muslim.ui.HisnTheme
import app.hisn.muslim.ui.HomeScreen
import app.hisn.muslim.ui.SearchScreen
import app.hisn.muslim.ui.SettingsScreen
import app.hisn.muslim.ui.TasbihScreen

class MainActivity : ComponentActivity() {
    private val openCat = mutableStateOf<Int?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openCat.value = intent?.getIntExtra("catId", -1)?.takeIf { it > 0 }
        setContent { HisnApp(openCat) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openCat.value = intent.getIntExtra("catId", -1).takeIf { it > 0 }
    }
}

@Composable
fun HisnApp(openCat: MutableState<Int?>) {
    val vm: AppViewModel = viewModel()
    val dark = when (vm.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }
    HisnTheme(dark) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (!vm.ready) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                } else {
                    Root(vm, openCat)
                }
            }
        }
    }
}

private class TabItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun Root(vm: AppViewModel, openCat: MutableState<Int?>) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    LaunchedEffect(openCat.value) {
        openCat.value?.let { nav.navigate("category/$it"); openCat.value = null }
    }
    val tabs = listOf(
        TabItem("home", "الرئيسية", Icons.Filled.Home),
        TabItem("favorites", "المفضلة", Icons.Filled.Favorite),
        TabItem("tasbih", "المسبحة", Icons.Filled.TouchApp),
        TabItem("settings", "الإعدادات", Icons.Filled.Settings),
    )
    val showBar = tabs.any { it.route == route }
    val openZekr: (Int, Int) -> Unit = { c, i -> nav.navigate("zekr/$c/$i") }
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, null) },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") {
                HomeScreen(vm, onCat = { nav.navigate("category/$it") }, onSearch = { nav.navigate("search") }, onZekr = openZekr)
            }
            composable("favorites") { FavoritesScreen(vm, openZekr) }
            composable("tasbih") { TasbihScreen(vm) }
            composable("settings") { SettingsScreen(vm) { nav.navigate("about") } }
            composable("about") { AboutScreen { nav.popBackStack() } }
            composable("search") { SearchScreen({ nav.popBackStack() }, openZekr) }
            composable("category/{id}", listOf(navArgument("id") { type = NavType.IntType })) { e ->
                CategoryScreen(vm, e.arguments!!.getInt("id"), { nav.popBackStack() }, openZekr)
            }
            composable(
                "zekr/{id}/{i}",
                listOf(navArgument("id") { type = NavType.IntType }, navArgument("i") { type = NavType.IntType }),
            ) { e ->
                DetailScreen(vm, e.arguments!!.getInt("id"), e.arguments!!.getInt("i")) { nav.popBackStack() }
            }
        }
    }
}
