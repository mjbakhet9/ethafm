@file:OptIn(ExperimentalMaterial3Api::class)

package app.hisn.muslim.ui

import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.hisn.muslim.data.AppViewModel
import app.hisn.muslim.data.Zekr
import app.hisn.muslim.data.arabicDigits
import app.hisn.muslim.data.rich

@Composable
fun BackTopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع") }
        },
        actions = actions,
    )
}

@Composable
fun navBarBottom(extra: Dp = 16.dp): PaddingValues =
    PaddingValues(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + extra)

@Composable
fun readStyle(scale: Float, base: Float = 24f): TextStyle = TextStyle(
    fontFamily = ReadFont,
    fontSize = (base * scale).sp,
    lineHeight = (base * scale * 1.85f).sp,
    color = MaterialTheme.colorScheme.onSurface,
)

@Composable
fun rememberRich(src: String): AnnotatedString {
    val cs = MaterialTheme.colorScheme
    return remember(src, cs) {
        rich(
            src,
            verse = SpanStyle(fontFamily = QuranFont, color = cs.primary),
            note = SpanStyle(color = cs.onSurfaceVariant, fontSize = 0.8.em),
            mark = SpanStyle(color = cs.tertiary, fontSize = 0.6.em, baselineShift = BaselineShift.Superscript),
        )
    }
}

/** Selectable (long-press to select any part, then copy) Arabic text. */
@Composable
fun SelectableRich(src: String, scale: Float, base: Float = 24f) {
    SelectionContainer {
        Text(rememberRich(src), style = readStyle(scale, base))
    }
}

fun copyToClipboard(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    cm.setPrimaryClip(android.content.ClipData.newPlainText("azkar", text))
    Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
}

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(send, "مشاركة"))
}

@Composable
fun CounterButton(z: Zekr, vm: AppViewModel, modifier: Modifier = Modifier) {
    val n = vm.counts[z.id] ?: 0
    val done = n >= z.repeat
    val view = LocalView.current
    FilledTonalButton(
        modifier = modifier,
        onClick = {
            if (!done) {
                val finished = vm.tap(z)
                if (vm.haptics) {
                    view.performHapticFeedback(
                        if (finished) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.VIRTUAL_KEY,
                    )
                }
            }
        },
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null)
            Text("  تمّ", fontWeight = FontWeight.Bold)
        } else if (z.repeat > 1) {
            Text("اضغط للعدّ  ${arabicDigits(n)} / ${arabicDigits(z.repeat)}", fontWeight = FontWeight.Bold)
        } else {
            Text("اضغط عند الانتهاء")
        }
    }
}

val SpaceV = Arrangement.spacedBy(12.dp)
