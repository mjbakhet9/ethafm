package app.hisn.muslim.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.hisn.muslim.MainActivity
import app.hisn.muslim.R
import java.util.Calendar

object Reminders {
    const val PREFS = "hisn"
    private const val CHANNEL = "azkar_reminders"

    // morning azkar / evening azkar category ids
    val CATS = intArrayOf(27, 135)
    private val TITLES = arrayOf("أذكار الصباح", "أذكار المساء")
    private val BODIES = arrayOf(
        "ابدأ يومك بذكر الله، حان وقت أذكار الصباح",
        "حان وقت أذكار المساء، حصّن نفسك بذكر الله",
    )

    private fun alarmIntent(ctx: Context, kind: Int) = PendingIntent.getBroadcast(
        ctx, 100 + kind, Intent(ctx, ReminderReceiver::class.java).putExtra("kind", kind),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    fun schedule(ctx: Context, kind: Int) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val h = sp.getInt("r${kind}_h", if (kind == 0) 6 else 17)
        val m = sp.getInt("r${kind}_m", 0)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, alarmIntent(ctx, kind))
    }

    fun cancel(ctx: Context, kind: Int) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent(ctx, kind))
    }

    fun scheduleAll(ctx: Context) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (k in 0..1) if (sp.getBoolean("r${k}_on", false)) schedule(ctx, k)
    }

    fun notify(ctx: Context, kind: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "تذكيرات الأذكار", NotificationManager.IMPORTANCE_DEFAULT))
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(
            ctx, 200 + kind,
            Intent(ctx, MainActivity::class.java).putExtra("catId", CATS[kind])
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(TITLES[kind])
            .setContentText(BODIES[kind])
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(300 + kind, n)
        } catch (_: SecurityException) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getIntExtra("kind", 0).coerceIn(0, 1)
        val on = context.getSharedPreferences(Reminders.PREFS, Context.MODE_PRIVATE).getBoolean("r${kind}_on", false)
        if (!on) return
        Reminders.notify(context, kind)
        Reminders.schedule(context, kind) // next day
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.scheduleAll(context)
    }
}
