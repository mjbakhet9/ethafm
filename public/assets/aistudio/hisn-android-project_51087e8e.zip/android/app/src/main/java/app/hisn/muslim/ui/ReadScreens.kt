@file:OptIn(ExperimentalMaterial3Api::class)

package app.hisn.muslim.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.hisn.muslim.data.AppViewModel
import app.hisn.muslim.data.Store
import app.hisn.muslim.data.Zekr
import app.hisn.muslim.data.arabicDigits
import app.hisn.muslim.data.copyAll
import app.hisn.muslim.data.copyZekr
import app.hisn.muslim.data.plain
import app.hisn.muslim.data.shareText

@Composable
private fun KeepScreenOn(on: Boolean) {
    val view = LocalView.current
    DisposableEffect(on) {
        view.keepScreenOn = on
        onDispose { view.keepScreenOn = false }
    }
}

@Composable
fun CategoryScreen(vm: AppViewModel, catId: Int, onBack: () -> Unit, onOpen: (Int, Int) -> Unit) {
    val cat = Store.cat(catId) ?: return
    KeepScreenOn(vm.keepOn)
    val ctx = LocalContext.current
    androidx.compose.material3.Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        topBar = {
            BackTopBar(cat.title, onBack) {
                IconButton({ vm.resetCategory(cat) }) { Icon(Icons.Filled.Refresh, "إعادة العدّ") }
            }
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 16.dp + navBarBottom(0.dp).calculateBottomPadding()),
            verticalArrangement = SpaceV,
        ) {
            itemsIndexed(cat.azkar, key = { _, z -> z.id }) { i, z ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (cat.azkar.size > 1) {
                            Text(
                                "${arabicDigits(i + 1)} / ${arabicDigits(cat.azkar.size)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.tertiary,
                            )
                        }
                        SelectableRich(z.text, vm.fontScale)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CounterButton(z, vm, Modifier.weight(1f))
                            IconButton({ vm.toggleFav(z.id) }) {
                                val fav = z.id in vm.favorites
                                Icon(
                                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "مفضلة",
                                    tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            IconButton({ copyToClipboard(ctx, z.copyZekr(true)) }) { Icon(Icons.Filled.ContentCopy, "نسخ") }
                            IconButton({ onOpen(cat.id, i) }) {
                                Icon(Icons.Filled.MenuBook, "الشرح", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppViewModel, catId: Int, index: Int, onBack: () -> Unit) {
    val cat = Store.cat(catId) ?: return
    KeepScreenOn(vm.keepOn)
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = index.coerceIn(0, cat.azkar.size - 1)) { cat.azkar.size }
    val z = cat.azkar[pager.currentPage]
    LaunchedEffect(pager.currentPage) { vm.setLastRead(cat.id, pager.currentPage) }
    var menu by remember { mutableStateOf(false) }
    androidx.compose.material3.Scaffold(
        contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
        topBar = {
            BackTopBar("${cat.title}  (${arabicDigits(pager.currentPage + 1)}/${arabicDigits(cat.azkar.size)})", onBack) {
                val fav = z.id in vm.favorites
                IconButton({ vm.toggleFav(z.id) }) {
                    Icon(
                        if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "مفضلة",
                        tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                }
                IconButton({ shareText(ctx, z.shareText()) }) { Icon(Icons.Filled.Share, "مشاركة") }
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "نسخ") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    @Composable fun item(label: String, text: String) = DropdownMenuItem(
                        text = { Text(label) },
                        onClick = { menu = false; copyToClipboard(ctx, text) },
                    )
                    item("نسخ الذكر", z.copyZekr(false))
                    item("نسخ الذكر مع التخريج", z.copyZekr(true))
                    if (z.sharh.isNotBlank()) item("نسخ الشرح", plain(z.sharh))
                    if (z.hadeth.isNotBlank()) item("نسخ الحديث", plain(z.hadeth))
                    if (z.benefit.isNotBlank()) item("نسخ الفوائد", plain(z.benefit))
                    HorizontalDivider()
                    item("نسخ الكل", z.copyAll())
                }
            }
        },
    ) { pad ->
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize().padding(pad), key = { cat.azkar[it].id }) { page ->
            ZekrPage(vm, cat.azkar[page])
        }
    }
}

@Composable
private fun ZekrPage(vm: AppViewModel, z: Zekr) {
    val ctx = LocalContext.current
    val sections = buildList {
        if (z.sharh.isNotBlank()) add("الشرح" to z.sharh)
        if (z.hadeth.isNotBlank()) add("الحديث" to z.hadeth)
        if (z.benefit.isNotBlank()) add("الفوائد" to z.benefit)
    }
    var tab by rememberSaveable(z.id) { mutableStateOf(0) }
    var showSource by rememberSaveable(z.id) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp + navBarBottom(0.dp).calculateBottomPadding()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SelectableRich(z.text, vm.fontScale, 26f)
                CounterButton(z, vm, Modifier.fillMaxWidth())
            }
        }
        if (z.footnote.isNotBlank()) {
            TextButton({ showSource = !showSource }) {
                Text(if (showSource) "إخفاء التخريج والمصدر" else "عرض التخريج والمصدر")
            }
            if (showSource) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Column(Modifier.padding(16.dp)) { SelectableRich(z.footnote, vm.fontScale, 18f) }
                }
            }
        }
        if (sections.isNotEmpty()) {
            val sel = tab.coerceIn(0, sections.size - 1)
            TabRow(selectedTabIndex = sel, containerColor = MaterialTheme.colorScheme.background) {
                sections.forEachIndexed { i, (name, _) ->
                    Tab(selected = i == sel, onClick = { tab = i }, text = { Text(name, fontWeight = FontWeight.Bold) })
                }
            }
            val (name, body) = sections[sel]
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("نص $name", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.weight(1f))
                IconButton({ copyToClipboard(ctx, plain(body)) }) { Icon(Icons.Filled.ContentCopy, "نسخ $name") }
            }
            LongText(body, vm.fontScale)
        }
    }
}

/** Long scholarly text, split into selectable paragraphs; short lines ending with ':' are headings. */
@Composable
private fun LongText(body: String, scale: Float) {
    androidx.compose.foundation.text.selection.SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            body.split('\n').filter { it.isNotBlank() }.forEach { line ->
                val heading = line.trim().length < 45 && line.trim().endsWith(":")
                Text(
                    rememberRich(line.trim()),
                    style = readStyle(scale, 20f).let { if (heading) it.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) else it },
                )
            }
        }
    }
}
