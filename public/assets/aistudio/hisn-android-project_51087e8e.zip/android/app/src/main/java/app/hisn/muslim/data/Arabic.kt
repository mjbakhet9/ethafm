package app.hisn.muslim.data

object Arabic {
    private fun isMark(c: Char) =
        c in 'ً'..'ٟ' || c == 'ٰ' || c in 'ۖ'..'ۭ' || c == 'ـ'

    private fun fold(c: Char): Char = when (c) {
        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
        'ى' -> 'ي'
        'ة' -> 'ه'
        'ؤ' -> 'و'
        'ئ' -> 'ي'
        else -> c
    }

    /** Removes tashkeel and unifies letter variants so searching ignores them. */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) if (!isMark(c)) sb.append(fold(c))
        return sb.toString()
    }

    /** A short piece of [src] around the first match of the already normalized [nq]. */
    fun snippet(src: String, nq: String): String {
        val sb = StringBuilder(src.length)
        val map = ArrayList<Int>(src.length)
        src.forEachIndexed { i, c -> if (!isMark(c)) { sb.append(fold(c)); map.add(i) } }
        val p = sb.indexOf(nq)
        if (p < 0 || map.isEmpty()) return src.take(90).replace('\n', ' ')
        val s = map[maxOf(0, p - 25)]
        val e = map[minOf(map.size - 1, p + nq.length + 70)]
        return src.substring(s, e + 1).replace('\n', ' ').trim()
    }
}
