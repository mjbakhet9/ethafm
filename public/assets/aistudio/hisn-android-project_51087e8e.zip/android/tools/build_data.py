"""Builds app/src/main/assets/azkar.json (Arabic only) from the original AzkarDB.db.

usage: python3 -I build_data.py AzkarDB.db ../app/src/main/assets/azkar.json

Markup written to the JSON (parsed by the app, see Markup.kt):
  <v>..</v>  Quran verse        <n>k</n>  footnote marker k
  <s>..</s>  scholar/narrator note (small, muted)
"""
import json, re, sqlite3, sys

db, out = sys.argv[1], sys.argv[2]
c = sqlite3.connect(f"file:{db}?mode=ro", uri=True)


def fix_verses(t):
    # two records use a second <7> where </7> was meant
    if t.count("<7>") != t.count("</7>"):
        parts = t.split("<7>")
        t = parts[0]
        for i, p in enumerate(parts[1:]):
            t += ("<7>" if i % 2 == 0 else "</7>") + p
        t = t.replace("</7>}", "</7>")
    return t


def clean_text(t):
    t = fix_verses(fix_glyphs((t or "").replace("\r", "")))
    t = re.sub(r"<F\d+>", "", t)
    t = re.sub(r"<FN>\(?(\d+)\)?</FN>", r"<n>\1</n>", t)
    t = t.replace("<7>", "<v>").replace("</7>", "</v>")
    t = re.sub(r"</?1>", "", t)
    return re.sub(r"[ \t]+\n", "\n", t).strip()


# The original app drew honorifics with a private symbol font (private-use code points).
# Context-checked meaning of each code; written out as normal Arabic text so any font works.
PUA = {
    "\uF072": "صلى الله عليه وسلم",
    "\uF026\uF02F": "صلى الله عليه وسلم",
    "\uF049": "تعالى",
    "\uF055": "تعالى",
    "\uF074": "رضي الله عنه",
    "\uF079": "رضي الله عنهم",
    "\uF075": "عليه السلام",
    "\uFC6B": "\uFD3F",  # verse open bracket (Quran font glyph)
    "\uFC6A": "\uFD3E",  # verse close bracket
    "\uFBEC": "",         # stray Quran-font waqf mark
}


def fix_glyphs(t):
    for k in sorted(PUA, key=len, reverse=True):
        t = t.replace(k, PUA[k])
    return t


def clean_long(t):
    t = fix_glyphs((t or "").replace("\r", "")).replace("\t", " ")
    # verses written between ornate brackets are shown in the Quran font
    t = re.sub(r"\uFD3F([^\uFD3F\uFD3E]{1,900}?)\uFD3E", r"<v>\1</v>", t)
    t = re.sub(r"/55(.*?)/55", r"<s>\1</s>", t, flags=re.S)
    t = re.sub(r"[ ]{2,}", " ", t)
    t = re.sub(r"[ ]+\n", "\n", t)
    return t.strip()


foot = {i: fix_glyphs((t or "").replace("\r", "")).strip() for i, t, *_ in c.execute("select * from AzkarFootNotes")}
cats, used = [], 0
for cid, title in c.execute("select CategoryID, Category from HSN_Categories_Ar order by Sort"):
    azkar = []
    q = """select z.ZekarID, z.ZekarText, z.RepeatNumber, z.ZekarSharh, z.ZekarHadeth, z.ZekarBenefit
           from HSN_CategoriesHSN_Ar m join HSN_Ar z on z.ZekarID = m.ZekarID
           where m.CategoryID = ? order by m.sort"""
    for zid, text, rep, sharh, hadeth, benefit in c.execute(q, (cid,)):
        m = re.search(r"<F(\d+)>", text or "")
        fn = foot.get(int(m.group(1)), "") if m else ""
        azkar.append({
            "id": zid, "t": clean_text(text), "r": int(rep or 1), "f": fn,
            "sh": clean_long(sharh), "hd": clean_long(hadeth), "bn": clean_long(benefit),
        })
        used += 1
    cats.append({"id": cid, "title": title.strip(), "z": azkar})

with open(out, "w", encoding="utf-8") as f:
    json.dump({"cats": cats}, f, ensure_ascii=False, separators=(",", ":"))
print(len(cats), "categories", used, "azkar")
